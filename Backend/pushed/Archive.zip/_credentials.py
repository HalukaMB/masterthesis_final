

ckey = 'szIul7ZRYlIoYB3Vp5kyyj42u'
consumer_secret = 'MG18KBN61TY5adittIJRweMzsjxnhspXSKmhMZuMGweYqlheUR'
access_token_key = '867428375383728129-cmzkW7Y66ioJcWhOt420O1MBiyWygVU'
access_token_secret = 'tAdBBmW16j2nTwBMMPT8ZlgqGUmgzR9SRtwbDRkUDiXZL'
LOCAL_PATH = '/Users/halukamaier-borst/Desktop/test/'
AWS_ACCESS_KEY_ID = 'AKIAINHJXRZCXT3XL2YQ'
AWS_SECRET_ACCESS_KEY = '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'
